<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>By <a href="#">Felipe Martinez Leiva</a></b>
    </div>
    <strong>Copyright &copy; 2021 Control de Asistencia y Sistema de Nómina </strong>
</footer>
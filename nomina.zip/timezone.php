<?php
	$timezone = 'America/Bogota';
	date_default_timezone_set($timezone);
?>